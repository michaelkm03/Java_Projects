/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author michaelmontgomery
 */
public interface Commands {
    
    void powerOn();
    
    void powerOff();
    
    void speedUp();
    
    void slowDown();
    
    void turnRight();
    
    void turnLeft();
    
    void displayInfo();
    
}